<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent;
use action\Score;
use action\Element;
use action\Geometry;
use php\gui\UXDialog;


class MainModule extends AbstractModule
{

	/**
	 * @event collisionTimer.action 
	 **/
	function doCollisionTimerAction(ScriptEvent $event)
	{	

		if (Geometry::intersect($this->enemy1, $this->player))
			$this->stopGame->call();

		if (Geometry::intersect($this->enemy2, $this->player))
			$this->stopGame->call();

		
	}

	/**
	 * @event scoreTimer.action 
	 **/
	function doScoreTimerAction(ScriptEvent $event)
	{	
		Score::inc('global', 1);
		Element::setText($this->scoreLabel, 'Счет: ');
		Element::appendText($this->scoreLabel, \action\Score::get('global'));

		
	}

	/**
	 * @event stopGame.action 
	 **/
	function doStopGameAction(ScriptEvent $event)
	{	
		$this->behaviour($this->enemy1, 'behaviour\custom\RandomMovementAnimationBehaviour')->disable();
		$this->behaviour($this->enemy2, 'behaviour\custom\RandomMovementAnimationBehaviour')->disable();
		$this->scoreTimer->enabled = false;
		UXDialog::show('Game Over');

		if (uiConfirm('Хотите начать с начала?'))
		{
			Score::set('global', 0);
			$this->scoreTimer->enabled = true;
			$this->behaviour($this->enemy1, 'behaviour\custom\RandomMovementAnimationBehaviour')->enable();
			$this->behaviour($this->enemy2, 'behaviour\custom\RandomMovementAnimationBehaviour')->enable();
		}
		else
		{
			app()->shutdown();
		}
		
	}



}
