<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent;
use action\Score;
use action\Element;
use php\gui\UXDialog;


class MainModule extends AbstractModule
{

	/**
	 * @event timer.action 
	 **/
	function doTimerAction(ScriptEvent $event)
	{	
		Score::inc('global', -1);

		if (Score::get('global') > -1)
		{
			Element::setText($this->label, \action\Score::get('global'));
			$this->button->enabled = false;
		}
		else
		{
			$event->sender->enabled = false;
			$this->button->enabled = true;
			UXDialog::show('Старт!');
		}
		
	}

}
