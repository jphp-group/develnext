<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent;
use action\Score;
use action\Element;


class MainForm extends AbstractForm
{

	/**
	 * @event button.action 
	 **/
	function doButtonAction(UXEvent $event)
	{	
		Score::set('global', 60);
		Element::setText($this->label, \action\Score::get('global'));
		$this->timer->enabled = true;
		$event->sender->enabled = false;

		
	}

}
