<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\game\event\UXCollisionEvent; 
use php\gui\UXDialog; 
use php\gui\event\UXEvent; 
use php\gui\event\UXMouseEvent; 
use game\Jumping; 
use php\gui\event\UXKeyEvent; 


class MainForm extends AbstractForm
{

    /**
     * @event player.collision-enemy 
     **/
    function doPlayerCollisionenemy(UXCollisionEvent $event = null)
    {
        // +Actions: 3 //
        
    }

    /**
     * @event enemy.create 
     **/
    function doEnemyCreate(UXEvent $event = null)
    {
        // +Actions: 7 //
    }

    /**
     * @event gameOver.click 
     **/
    function doGameOverClick(UXMouseEvent $event = null)
    {
        // +Actions: 1 //
    }


    /**
     * @event gameOver.keyDown-Space 
     **/
    function doGameOverKeyDownSpace(UXKeyEvent $event = null)
    {
        // +Actions: 1 //
    }



    /**
     * @event click 
     **/
    function doClick(UXMouseEvent $event = null)
    {
        // +Actions: 1 //
    }










}
