<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent; 


class MainModule extends AbstractModule
{

	/**
	 * @event timer.action 
	 **/
	function doTimerAction(ScriptEvent $event = null)
	{
		// +Actions: 6 //
	}

	/**
	 * @event restart.action 
	 **/
	function doRestartAction(ScriptEvent $event = null)
	{
		// +Actions: 7 //
	}

	/**
	 * @event gameEnd.action 
	 **/
	function doGameEndAction(ScriptEvent $event = null)
	{
		// +Actions: 9 //
	}


}
