<?php
namespace app\modules;

use php\gui\framework\AbstractModule;


class AppModule extends AbstractModule
{

}