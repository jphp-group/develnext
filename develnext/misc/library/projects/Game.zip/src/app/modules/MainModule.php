<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent; 
use action\Element; 
use action\Score; 
use game\Jumping; 


class MainModule extends AbstractModule
{

	/**
	 * @event timer.action 
	 **/
	function doTimerAction(ScriptEvent $event = null)
	{

		if (rand(1, 2) == 2)
			$this->create('enemy', null, -50, rand(0, 500));

		else
			$this->create('enemy', null, 600, rand(0, 500));
		Element::setText($this->form('App')->scoreLabel, \action\Score::get('global'));
		Score::inc('global', 1);

		// +Actions: 6 //
	}

	/**
	 * @event restart.action 
	 **/
	function doRestartAction(ScriptEvent $event = null)
	{
		Score::set('global', 0);
		Jumping::toStart($this->player);
		$this->gameOver->hide();
		$this->player->show();
		$this->cursorImg->hide();
		$this->timer->enabled = true;
		$event->sender->enabled = false;

		// +Actions: 7 //
	}

	/**
	 * @event gameEnd.action 
	 **/
	function doGameEndAction(ScriptEvent $event = null)
	{
		$this->instances('MainForm.enemy')->free();
		$this->player->hide();
		$this->timer->enabled = false;
		Element::setText($this->gameOver, 'Game Over');
		$this->gameOver->show();
		$this->cursorImg->show();
		$this->restart->enabled = true;
		$this->gameOver->requestFocus();
		$this->restart->enabled = true;

		// +Actions: 9 //
	}


}
