<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\game\event\UXCollisionEvent; 
use php\gui\UXDialog; 
use php\gui\event\UXEvent; 
use php\gui\event\UXMouseEvent; 
use game\Jumping; 
use php\gui\event\UXKeyEvent; 
use action\Animation; 


class MainForm extends AbstractForm
{

	/**
	 * @event player.collision-enemy 
	 **/
	function doPlayerCollisionenemy(UXCollisionEvent $event = null)
	{
		$this->gameEnd->call();
		;		return $event->consume();

		// +Actions: 3 //
		
	}

	/**
	 * @event enemy.create 
	 **/
	function doEnemyCreate(UXEvent $event = null)
	{
		Animation::fadeOut($event->sender, 10, function () use ($event) {
			Animation::fadeIn($event->sender, 4000);
			$event->sender->enabled = true;
			$event->sender->randomMove->enable();
			waitAsync(rand(5000, 10000), function () use ($event) {
				Animation::fadeOut($event->sender, 1000, function () use ($event) {
					$event->sender->free();
				});
			});
		});

		// +Actions: 7 //
	}

	/**
	 * @event gameOver.click 
	 **/
	function doGameOverClick(UXMouseEvent $event = null)
	{
		$this->restart->call();

		// +Actions: 1 //
	}


	/**
	 * @event gameOver.keyDown-Space 
	 **/
	function doGameOverKeyDownSpace(UXKeyEvent $event = null)
	{
		$this->restart->call();

		// +Actions: 1 //
	}



	/**
	 * @event click 
	 **/
	function doClick(UXMouseEvent $event = null)
	{
		$this->restart->call();

		// +Actions: 1 //
	}

	/**
	 * @event player.outside-partly 
	 **/
	function doPlayerOutsidepartly(UXEvent $event = null)
	{
		$this->gameEnd->call();

		// +Actions: 1 //
	}









}
