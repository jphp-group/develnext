<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent;
use action\Element;
use php\io\Stream;


class MainModule extends AbstractModule
{

	/**
	 * @event fileChooser.action 
	 **/
	function doFileChooserAction(ScriptEvent $event)
	{	
		Element::loadContentAsync($this->textArea, uiText($this->fileChooser), function () use ($event) {
		});

		
	}

	/**
	 * @event fileSaver.action 
	 **/
	function doFileSaverAction(ScriptEvent $event)
	{	
		$this->file->path = uiText($this->fileSaver);
		Element::setText($this->file, uiText($this->textArea));

		
	}

}
