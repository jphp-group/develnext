<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXEvent;
use php\gui\UXDialog;

const MY_CONST = 20;

class MainForm extends AbstractForm
{	

	/**
	 * @event button.action 
	 **/
	function doButtonAction(UXEvent $event)
	{	
		UXDialog::show('Hello World!');

		
	}




}
