<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent;
use action\Element;


class MainForm extends AbstractForm
{

	/**
	 * @event image3.click 
	 **/
	function doImage3Click(UXMouseEvent $event)
	{	
		app()->shutdown();

		
	}

	/**
	 * @event image.click 
	 **/
	function doImageClick(UXMouseEvent $event)
	{	
		
	}

	/**
	 * @event image3.mouseEnter 
	 **/
	function doImage3MouseEnter(UXMouseEvent $event)
	{	
		Element::setText($this->hint, 'Выход из программы');

		
	}

	/**
	 * @event image.mouseMove 
	 **/
	function doImageMouseMove(UXMouseEvent $event)
	{	
		Element::setText($this->hint, '');

		
	}

	/**
	 * @event label.mouseEnter 
	 **/
	function doLabelMouseEnter(UXMouseEvent $event)
	{	
		Element::setText($this->hint, 'Текущее время');

		
	}


}
