<?php
namespace app\modules;

use std, gui, framework, app, game;


class Game extends AbstractModule
{
    private $currentLevel;
    
    private $levels = ['Level1', 'Level2', 'Level3'];

    function loadLevel($name, $showLoading = true)
    {
        $this->currentLevel = $name; 
        
        $pane = app()->form('App')->game->phys;
        
        if ($showLoading) {
            $pane->loadScene('LoadingLevel');
        }
        
        uiLater(function () use ($pane, $name) {
            $pane->loadScene($name);
        });
    }
    
    function loadFinalLevel()
    {
        $this->loadLevel('FinalLevel', false);
    }
    
    function loadFirstLevel()
    {
        $this->loadLevel($this->levels[0]);
    }
    
    /**
     * @return bool
     */
    function loadNextLevel()
    {
        foreach ($this->levels as $i => $level) {
            if ($level == $this->getCurrentLevel()) {
                $nextLevel = $this->levels[$i + 1];
                
                if ($nextLevel) {
                    $this->loadLevel($nextLevel);
                    return true;
                }
            }
        }
        
        return false;
    }
    
    function getCurrentLevel()
    {
        return $this->currentLevel;
    }
}