<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent; 


class MainModule extends AbstractModule
{

	/**
	 * @event timer.action 
	 **/
	function doTimerAction(ScriptEvent $event = null)
	{
		app()->shutdown();

		// +Actions: 1 //
	}

}
