<?php
namespace app\forms;

use std, gui, framework, app;


class App extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->loadLevel('MenuLevel');
    }
}
