<?php
namespace app\forms;

use framework;
use php\game\UXGameEntity;
use std, gui, framework, app, game;
use action\Collision; 


class Proto extends AbstractForm
{

    /**
     * @event ball.collision-brick 
     */
    function doBallCollisionbrick(UXCollisionEvent $event = null)
    {
        Collision::bounce($event->sender, $event->normal, 1.02);
        
        $event->target->free();
        
        if (Score::get('bricks') <= 0) {
            $event->sender->free();
            
            $succes = $this->loadNextLevel();
            
            if (!$succes) {
                $this->loadFinalLevel();
            }
        }
    }

    /**
     * @event ball.collision-player 
     */
    function doBallCollisionplayer(UXCollisionEvent $event = null)
    {    
        
    }

    /**
     * @event ball.create 
     */
    function doBallCreate(UXEvent $event = null)
    {    
        
    }

    /**
     * @event ball.outside 
     */
    function doBallOutside(UXEvent $event = null)
    {    
        
    }

    /**
     * @event ball.collision-wall 
     */
    function doBallCollisionwall(UXEvent $event = null)
    {
    }

    /**
     * @event ball.collision-v_wall 
     */
    function doBallCollisionv_wall(UXCollisionEvent $event = null)
    {    
        
    }

    /**
     * @event brick.create 
     */
    function doBrickCreate(UXEvent $event = null)
    {
        Score::inc('bricks', 1);
    
        $anim = 'green';
        
        switch ($this->getCurrentLevel()) {
            case 'Level1':
                $anim = 'green';
                break;
                
            case 'Level2':
                $anim = 'red';
                break;
                
            case 'Level3':
                $anim = 'blue';
                break;        
        }
        
        $event->sender->sprite->currentAnimation = $anim;
    }

    /**
     * @event brick.destroy 
     */
    function doBrickDestroy(UXEvent $event = null)
    {    
        Score::inc('bricks', -1);
    }
}
