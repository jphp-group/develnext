<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\gui\event\UXMouseEvent; 


class GameOver extends AbstractForm
{

	/**
	 * @event buttonAlt.action 
	 **/
	function doButtonAltAction(UXEvent $event = null)
	{
		$this->originForm('MainForm')->phys->loadScene('MainForm');

		// +Actions: 1 //
	}



}
