<?php
namespace app\forms;

use std, gui, framework, app;


class Level1 extends AbstractForm
{

}