<?php
namespace app\forms;

use std, gui, framework, app;


class Level2 extends AbstractForm
{

}