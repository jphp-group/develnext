<?php
namespace app\forms;

use std, gui, framework, app;


class MenuLevel extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $event = null)
    {
        $this->loadFirstLevel();
    }

}
