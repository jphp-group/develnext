<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\gui\event\UXKeyEvent; 
use php\game\event\UXCollisionEvent; 
use php\gui\event\UXMouseEvent; 
use action\Collision; 
use action\Score; 
use action\Element; 
use php\lib\Str; 
use php\util\Regex; 


class Prototypes extends AbstractForm
{

	/**
	 * @event object.collision-button 
	 **/
	function doObjectCollisionbutton(UXCollisionEvent $event = null)
	{
		Collision::bounce($event->sender, $event->normal, 1.0);

		// +Actions: 1 //
	}

	/**
	 * @event object.collision-player 
	 **/
	function doObjectCollisionplayer(UXCollisionEvent $event = null)
	{
		Collision::bounce($event->sender, $event->normal, 1.0);
		uiLater( function () use ($event) {
		});

		// +Actions: 2 //
	}

	/**
	 * @event object.collision-brick 
	 **/
	function doObjectCollisionimage(UXCollisionEvent $event = null)
	{
		Collision::bounce($event->sender, $event->normal, 1.04);
		$event->target->free();
		uiLater( function () use ($event) {
		});

		// +Actions: 3 //
	}

	/**
	 * @event object.outside 
	 **/
	function doObjectOutside(UXEvent $event = null)
	{
		$GLOBALS['gameOver'] = 1;
		$this->originForm('MainForm')->phys->loadScene('GameOver');

		// +Actions: 2 //
	}

	/**
	 * @event object.create 
	 **/
	function doObjectCreate(UXEvent $event = null)
	{
		$GLOBALS['gameOver'] = 0;
		waitAsync(1500, function () use ($gameOver, $event) {
			$event->sender->phys->vspeed = 8.0;
			$event->sender->phys->hspeed = 3.0;
		});

		// +Actions: 4 //
	}

	/**
	 * @event brick.create 
	 **/
	function doBrickCreate(UXEvent $event = null)
	{
		Score::inc('enemyCount', 1);
		Element::setText($this->form('MainForm')->blocksLabel, 'blocks: ');
		Element::appendText($this->form('MainForm')->blocksLabel, \action\Score::get('enemyCount'));

		// +Actions: 3 //
	}

	/**
	 * @event brick.destroy 
	 **/
	function doBrickDestroy(UXEvent $event = null)
	{
		Score::inc('enemyCount', -1);
		Element::setText($this->form('MainForm')->blocksLabel, 'blocks: ');
		Element::appendText($this->form('MainForm')->blocksLabel, \action\Score::get('enemyCount'));
		;
		if (Score::get('enemyCount') < 1)

			if ($GLOBALS['gameOver'] == '0')
			{
				uiLater( function () use ($event) {
					$this->originForm('MainForm')->phys->loadScene('Win');
					
});		}
		// +Actions: 10 //
	}

	/**
	 * @event button.create 
	 **/
	function doButtonCreate(UXEvent $event = null)
	{
		$event->sender->enabled = true;

		// +Actions: 1 //
	}











}
