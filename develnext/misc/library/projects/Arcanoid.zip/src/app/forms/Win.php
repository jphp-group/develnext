<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 


class Win extends AbstractForm
{

	/**
	 * @event button.action 
	 **/
	function doButtonAction(UXEvent $event = null)
	{
		$this->originForm('MainForm')->phys->loadScene('MainForm');

		// +Actions: 1 //
	}

}
